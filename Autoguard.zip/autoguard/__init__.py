# autoguard package initialization
